var seLightBlue = 0xFF448AFF;
var seBlue = 0xFF2962FF;
var seDarkBlue = 0xFF002486;

var sePinkyRed = 0xFFFF1744;
var seDarkPinkyRed = 0xFFD50000;

var seLightCream = 0xFFFFCDB2;
var seCream = 0xFFFFB4A2;
var seDarkCream = 0xFFE18A6B;

var seLightGrey = 0xFFE0E0E0;
var seGrey = 0xFFBDBDBD;
var seDarkGrey = 0xFF9E9E9E;

var seYellow = 0xFFF9A825;
var seDarkYellow = 0xFFF57F17;

var sePurple = 0xFF8E24AA;
var seDarkPurple = 0xFF6A1B9A;

var seBorderWidth = 5.0;
var seButtonHeight = 60.0;
var seTextBoxHeight = 50.0;
